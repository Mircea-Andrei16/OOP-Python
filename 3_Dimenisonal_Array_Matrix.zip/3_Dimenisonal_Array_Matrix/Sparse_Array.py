import functions
def main(): ##infinite loop for showing the menu after every operation
   while(1):
       stop_menu = menu()
       if(stop_menu == 0): ## main() function stops when function menu retrun 0 which means
           break           ## we have chosen the 9-th line from the menu

def menu():
    choice = input("""
1: Creating the array
2: Printing array
3: Print the dimension of the array 
4: Reading the value of an element specified by its indices
5: Writing the value of an element specified by its indices and by its value
6: Adding and subtracting two arrays
7: Allowing to access an element through its indices
8: Creating a null matrix (with elements having only 0 values)
9: Exit
Please enter your choice: """)

    if choice == "1":
       print()
       functions.CreateList() ##create the sparse arrays. There are 4 pre-defined spars arrays than can be used in our problems 
       print("The array is created")
       print()
    elif choice == "2":
        print()
        functions.PrintList() ##a simple function that print the sparse array
        print()
    elif choice== "3":
        print()
        functions.Print_Dimension() ##prints the dimensions of the sparse array
        print()
    elif choice== "4":
        print()
        functions.Read_Value() ## this function print an element found by the indices that are given from the keyboard
        print()
    elif choice== "5":
        print()
        functions.Writing_Element() ## with this function we can add an element in the array
        print()
    elif choice== "6":
        print()
        functions.Add_Substract()  ## we add or substract two sparse arrays
        print()
    elif choice== "7":
        print()
        functions.Access_Element() ## a function that gives the oportunity to find an element with the help of the indices
        print()                    ## and permits to action 3 operation: read the element, change the element or erase from the list
    elif choice== "8":
        functions.Null_Matrix() ## make a sparse array with non null elements to be a sparse array with only 0 elements
    elif choice== "9":          ## Make the array empty again
        print("Goodbye!")
        return 0         ## with this we can stop the menu and the problem
    else:
        print("Please try again")

main() 