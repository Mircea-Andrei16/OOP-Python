List = []   ## a list where I store the elements of the sparse array
List_Dimensions = [] ## a list where I store the dimensions of the array

def CreateList():
    ## in this function I can choose 4 types of  spparse arrays, they only difference between them is given by 
    # their dimensions and how many elements  can be added in the arrays
    choice = input("""                            
1: File test 1: 0 elements can be added
2: File test 2: 2 elements can be added
3: File test 3: 4 elements can be added
4: File test 4: 5 elements can be added
Please enter your choice: """) 
    if choice =="1":
        f = open("array1.txt","r") ## read from the first file
        lines_list = f.readlines() ## lines_list will store the lines from the file
        k,i,j,n = (int(val) for val in lines_list[0].split()) ## we read the first line which contains the dimensions of the array(h, i, j)
        List_Dimensions.append(k)                             ## and the number of the elements from the array (n)
        List_Dimensions.append(i)                             ## we store the dimensions in the List_Dimensions
        List_Dimensions.append(j)
        for i in range(0,n):  ## we iterate through the elements 
            a = []
            k,i,j,value = (float(val) for val in lines_list[i+1].split()) ## the k,i,j are the indices where the value is stored
            k = int(k)                                                    ## we need to read in float beacause value is real
            i = int(i)                                                    # and then I transform the indices into int
            j = int(j)
            a.append(k)       ## in this 4 lines i create an auxiliar list a which will contain 4 elements, the indices
            a.append(i)        # and the value
            a.append(j)         #
            a.append(value)     #
            List.append(a)    ## I add the auxiliar list in the main list with the elements
    elif choice == "2":   ## in this case is repeated the algorith above but with the elements in the second file
            f = open("array2.txt","r")
            lines_list = f.readlines()
            k,i,j,n = (int(val) for val in lines_list[0].split())
            List_Dimensions.append(k)
            List_Dimensions.append(i)
            List_Dimensions.append(j)
            for i in range(0,n):
                 a = []
                 k,i,j,value = (float(val) for val in lines_list[i+1].split())
                 k = int(k)
                 i = int(i)
                 j = int(j)
                 a.append(k)
                 a.append(i)
                 a.append(j)
                 a.append(value)
                 List.append(a)
    elif choice == "3":  ## in this case is repeated the algorith above but with the elements in the third file
         f = open("array3.txt","r")
         lines_list = f.readlines()
         k,i,j,n = (int(val) for val in lines_list[0].split())
         List_Dimensions.append(k)
         List_Dimensions.append(i)
         List_Dimensions.append(j)
         for i in range(0,n):
                 a = []
                 k,i,j,value = (float(val) for val in lines_list[i+1].split())
                 k = int(k)
                 i = int(i)
                 j = int(j)
                 a.append(k)
                 a.append(i)
                 a.append(j)
                 a.append(value)
                 List.append(a)
    elif choice == "4":  ## in this case is repeated the algorith above but with the elements in the fourth file
        f = open("array4.txt","r")
        lines_list = f.readlines()
        k,i,j,n = (int(val) for val in lines_list[0].split())
        List_Dimensions.append(k)
        List_Dimensions.append(i)
        List_Dimensions.append(j)
        for i in range(0,n):
                 a = []
                 k,i,j,value = (float(val) for val in lines_list[i+1].split())
                 k = int(k)
                 i = int(i)
                 j = int(j)
                 a.append(k)
                 a.append(i)
                 a.append(j)
                 a.append(value)
                 List.append(a)
        
def PrintList():
    ## this function just prints the elements that are in the List 
    # representing the elements in the sparse array
    print()
    print("Elements of the sparse matrix that arent null are:")
    print()
    n = len(List) # number of elements in the list
    for x in List: #iterate trough the list
        print(x)
    print()

def Print_Dimension():
    #this function print the dimension of the sparse array
    print()
    print("The dimensions of the sparse matrix are:")
    print()
    print(List_Dimensions) #prints the elements in the list where the dimensions are stored
    print()

def Read_Value():
    # this function prints the value of the element with the indices enter from the keyboard
    # if the element is not in the list or the indices are not between 0..dimension the function will indicate that
    print()
    print("Give the indices of the specified element. The indices must be bigger than 0 or equal with 0")
    print("Please press enter after every idex")
    k = int(input()) ## read the indices from the keyboard 
    i = int(input()) #
    j = int(input()) #

    if k >= List_Dimensions[0] or i >= List_Dimensions[1] or j >= List_Dimensions[2]: #if the indices are bigger it will exit 
         print("The indices given are bigger than the dimension of the array")         #the function
         return                                                                            
        

    n = len(List) # number of elements in the list
    b = 0 # this variable helps to iterate trough the element
          #List[a][b] means element a and the b position in the element a
    for a in range(0,n): # I iterate trough the elements of the list 
             if List[a][b] == k: # if the  first index of the element is equal with the given one we can continue 
                 b += 1  # I increase the position in the element 
                 if List[a][b] == i: # I question if the second index is equal with the given one. if it ok we continue
                    b += 1 # I increase the position in the element 
                    if List[a][b] == j: # and lastly i question if the third is also equal
                        b += 1 # I positionate b at the place where the value is
                        print(List[a][b]) #print the value
                        return
                    else:
                        b = 0 # List[a][b] != j
                        continue
                 else:
                     b = 0 # List[a][b] != i
                     continue
             else:
                 b = 0  # List[a][b] == k
                 continue
    print("This element is not in the list") # prints if the indices given don't store a non null value
    
def Writing_Element():
    # i receive an element from the keyboard and i put it in the sparse array  
    total = 1 # variable that helps to calculate the total capacity of the array
    for i in List_Dimensions:
        total *= i #calculate the capcity of the array. I multiply the dimensions of the array
    
    procent = 1/total # procent represent how much in percent represent an element in the list
    procent = (procent) * (len(List)+1) # calculate if we can add one more element in the array

    if procent >= 0.1: #if the total represented from elements that are in the list and the other one that we want to add 
        print("The list is full!") # is more than 10%, => we can't add more element and we exist the function
        return
    # otherwise we ask for the element that we want to add 
    print("Give the indices and the value of the element. The indices must be bigger than 0 or equal with 0")
    print("Please press enter after every idex or the value")
    aux = [] # we use a auxiliar list where we store the element with the indices and the value
    k = int(input())  #read the indices of the element
    i = int(input())
    j = int(input())
    print("Give the value of the element")
    print()
    val = float(input()) #read the value of the element
    if k >= List_Dimensions[0] or i >= List_Dimensions[1] or j >= List_Dimensions[2]: #if the indices are bigger it will exit 
         print("The indices given are bigger than the dimension of the array")         #the function
         return        
    aux.append(k) #add in the auxiliar list
    aux.append(i) #
    aux.append(j) #
    aux.append(val) #

    n = len(List) # number of elements in the list
    b = 0 # helpfull variable that iterate through the element for the indices or for the value

    # for this array to be sparse we need that the indices of the elements to be in order otherwise is not sparse

    #here we add the element ,in O(n) time, in order such that the resultated array is also a sparse array
     
    for a in range(0,n): #iterate trough the elements
        if List[a][b] > k: # if the first index is bigger than the first index of the element that we want to add
            List.insert(a,aux) # add in the list in front of the current element in the list
            return
        elif List[a][b] == k: # if is equal it is a posibility to be good the other 2 indices be bigger than the indices of the element
             b += 1 # change the position to the nex index
             if List[a][b] > i: #if this one is bigger 
                 List.insert(a,aux) # add the element in front of the current element
                 return
             elif List[a][b] == i: #if the second indices are equal is a posibility that the third is bigger
                  b += 1 #change the position to the third
                  if List[a][b] > j: # if the third index is bigger 
                      List.insert(a,aux) #add in front
                      return
        b = 0 #after every element in the list reset the position variable 
        
    if n == len(List): #if the indices of the element are bigger than the actual elements of the list
        List.append(aux) # add the element at the end of the list
        return

def verification(k1,i1,j1,k2,i2,j2):
    # this function is used to determine if an element from an array is bigger, smaller or equal 
    # than an element from a different array 
    if k1 < k2: # first index of the element1 is smaller than the first index of element2 
        return 1 # return 1 represents is smaller
    else: #is equal or smaller 
        if k1 > k2:
            return 2 # return 1 represents is bigger
        if i1 < i2: # k1 == k2 go to second index and repeat the idea 
            return 1
        else:
            if i1 > i2:
                return 2
            if j1 < j2:
                return 1
            else:
                if j1 >j2:
                    return 2
                return 3 # return 3 is equal case k1 == k2 , i1 ==i2 , j1 == j2

def Add_Substract():
    # this function add or substract 2 sparse arrays.
    # Like in the sparse matrix adding and substracting, i thought that the arrays that i want to make add or substract need 
    # to have the same dimensions so this is the fisrt part of the function. The array that i used is an array with dimensions equal 
    # with the array in the fourth file. i used this type of array because has the most elements
    print("""For this function to work we need to use the 4-th file from the input 
because we need to have the same dimensions for both matrixes.

If you use another file please use the 8 choice for making the current matrix null
and then use choice 1 and choose the 4-th file""")
    choice =input("""Do you use another file?
0.NO
1.Yes
Please enter your choice: """)
    add = 0
    substract = 0
    if choice == "1":
       return
    if choice == "0": # here choose if you add or substract the arrays
       choose = input("""Do you want to add or to substract?
1.Add
2.Subtract
Please enter your choice: """)
       if choose == "1":
          add = 1
       if choose == "2":
          substract = 1
    f = open("SumArray.txt","r") # read from the specific folder. The algorithm used to create the list for the operation is identical
    lines_list = f.readlines()   # with the one used in the CreateList() function 
    List_Dimensions_Add_Substract = []
    List_Add_Substract = []
    k,i,j,n = (int(val) for val in lines_list[0].split())
    List_Dimensions_Add_Substract.append(k)
    List_Dimensions_Add_Substract.append(i)
    List_Dimensions_Add_Substract.append(j)
    for i in range(0,n):
        a = []
        k,i,j,value = (float(val) for val in lines_list[i+1].split())
        k = int(k)
        i = int(i)
        j = int(j)
        a.append(k)
        a.append(i)
        a.append(j)
        a.append(value)
        List_Add_Substract.append(a) #

    Sum_Array = [] # use an auxiliar list where we store the result of adding or substracting
    n = len(List) # number of elements in the first array
    m = len(List_Add_Substract) #number of elements in the second array
    i = 0 # iterator for the elements in the first array
    j = 0 # iterator for the elements in the second array
    while(i < n and j < m): # i used the merging algorithm
        verif = verification(List[i][0],List[i][1],List[i][2],List_Add_Substract[j][0],List_Add_Substract[j][1],List_Add_Substract[j][2])
        # verification function that helps to determine if the element from the List is smaller, bigger or equal than 
        # than the element from the List_Add_Substract 
        if verif == 1: #if is smaller means that  add or substract element from List with 0
            Sum_Array.append(List[i]) # add to the auxiliar matirx
            i += 1 # move forward in the List
        if verif == 2: #if is bigger means that  add or substract element from List with 0
            if add == 1: #here need to see if is adding or substracting beacuse is the second operand and the value could change 
                Sum_Array.append(List_Add_Substract[j]) #if is add we adding as it is
            else: #otherwise we change the value to -value using an auxiliar list
                a = []
                a.append(List_Add_Substract[j][0])
                a.append(List_Add_Substract[j][1])
                a.append(List_Add_Substract[j][2])
                a.append(-List_Add_Substract[j][3])
                Sum_Array.append(a)
            j += 1 #move forward in the List_Add_Substract
        if verif == 3: #if the indices are equal we need to add or substract the values using auxiliar list
            a = []
            a.append(List_Add_Substract[j][0])
            a.append(List_Add_Substract[j][1])
            a.append(List_Add_Substract[j][2]) # move the indices in the first positions  
            if add == 1:
                sum = List[i][3] + List_Add_Substract[j][3] #add the values
                if sum != 0: #if the sum == 0 we don't add in the Sum_Array because the value need to be non null
                    a.append(sum)
                    Sum_Array.append(a)
            else:
                diff = List[i][3] - List_Add_Substract[j][3]
                if diff != 0: #the same idea here
                    a.append(diff)
                    Sum_Array.append(a)
            i +=1 #move forward in List
            j +=1 #move forward in List_Add_Substract

    while(i < n): # if remains elements in List we adding in th sum_array list 
        Sum_Array.append(List[i])
        i += 1
    while(j < m): # if remains elements in List_Add_Substract we adding in th sum_array list
        if add==1:
           Sum_Array.append(List_Add_Substract[j])
        else:
            a = []
            a.append(List_Add_Substract[j][0])
            a.append(List_Add_Substract[j][1])
            a.append(List_Add_Substract[j][2])
            a.append(-List_Add_Substract[j][3])
            Sum_Array.append(a)
        j += 1

    print("The array formed making the operation is:")
    print()
    print(Sum_Array) #print the add or substract matrix

def Menu_Access(a,b):
    # menu used in the next function. Appears when we acces an element by its indices and we can print change or delete the element
    print()
    choice = input("""You accessed that you wanted. Here some things you can do with the element:
1. Read the element
2. Change the element with a different none-zero value
3. Change the element with a 0 value
Please enter your choice: """)

    if choice == "1":
        print(List[a][b]) #print the value
        return
    elif choice == "2":
        aux = float(input("Give the value that you want to be changed"))
        print()
        List[a][b] = aux #change the value
    elif choice =="3":
        List.pop(a) #delete the element

def Access_Element():
    #is the same algorithm as in reding an element, the only difference is that when we find the element we action the Menu_Access function
    print()
    print("Give the indices of the specified element. The indices must be bigger than 0 or equal with 0")
    print("Please press enter after every idex")
    k = int(input())
    i = int(input())
    j = int(input())
    n = len(List)
    b = 0
    for a in range(0,n):
             if List[a][b] == k:
                 b += 1
                 if List[a][b] == i:
                    b += 1
                    if List[a][b] == j:
                        b += 1
                        Menu_Access(a,b) #access the menu function
                        return
                    else:
                        b = 0
                        continue
                 else:
                     b = 0
                     continue
             else:
                 b = 0
                 continue
    print("This element is not in the list")
         
def Null_Matrix():
    # we make the sparse array to have only null elements. I erase all the information in the list where elemets are stored
    List.clear() 
