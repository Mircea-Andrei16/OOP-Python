class ship_positions:
    def __init__(self):
        self.array = []

    def add_array(self,x,y):
        self.array.append((x,y))

    def in_array(self,x,y):
        return (x,y) in self.array


class ship1:
    def __init__(self):
        self.Rotation_PointX = -1
        self.Rotation_PointY = -1
        self.Used = False
        self.Destroyed = False
        
    def is_used(self):
       return self.Used
        
    def attack(self,x,y):
       if self.Rotation_PointX == x and self.Rotation_PointY == y:
        return True
       else:
           return False
       

    def place_ship(self,x,y):
        self.Used = True
        self.Rotation_PointX = x
        self.Rotation_PointY = y

    def print(self):
        print(self.Used,self.Rotation_PointX,self.Rotation_PointY)
           
class ship2(ship1):
    def __init__(self):
        super().__init__()
        self.Tail1X = -1
        self.Tail1Y = -1
        self.tail = True

    def place_ship(self, x1, y1,x2,y2):
        self.Used = True
        self.Rotation_PointX = x1
        self.Rotation_PointY = y1
        self.Tail1X = x2
        self.Tail1Y = y2

    def attack_tail(self,x,y):
        if self.Tail1X == x and self.Tail1Y == y:
          return True
        else:
           return False

class ship3(ship1):
    def __init__(self):
        super().__init__()
        self.Tail1X = -1
        self.Tail1Y = -1
        self.Tail2X = -1
        self.Tail2Y = -1
        self.tail1 = True
        self.tail2 = True
       

    def place_ship(self, x1, y1,x2,y2,x3,y3):
        self.Used = True
        self.Rotation_PointX = x1
        self.Rotation_PointY = y1
        self.Tail1X = x2
        self.Tail1Y = y2
        self.Tail2X = x3
        self.Tail2Y = y3

    def attack_tail1(self,x,y):
        if self.Tail1X == x and self.Tail1Y == y:
          return True
        else:
           return False

    def attack_tail2(self,x,y):
        if self.Tail2X == x and self.Tail2Y == y:
          return True
        else:
           return False

class ship4(ship1):
    def __init__(self):
        super().__init__()
        self.Tail1X = -1
        self.Tail1Y = -1
        self.Tail2X = -1
        self.Tail2Y = -1
        self.tail1 = True
        self.tail2 = True

    def place_ship(self, x1, y1,x2,y2,x3,y3):
        self.Used = True
        self.Rotation_PointX = x1
        self.Rotation_PointY = y1
        self.Tail1X = x2
        self.Tail1Y = y2
        self.Tail2X = x3
        self.Tail2Y = y3

    def attack_tail1(self,x,y):
        if self.Tail1X == x and self.Tail1Y == y:
          return True
        else:
           return False

    def attack_tail2(self,x,y):
        if self.Tail2X == x and self.Tail2Y == y:
          return True
        else:
           return False

class ship5(ship1):
    def __init__(self):
        super().__init__()
        self.Tail1X = -1
        self.Tail1Y = -1
        self.Tail2X = -1
        self.Tail2Y = -1
        self.Tail3X = -1
        self.Tail3Y = -1
        self.tail1 = 0
        self.tail2 = 0
        self.tail3 = 0

    def place_ship(self, x1, y1,x2,y2,x3,y3,x4,y4):
        self.Used = True
        self.Rotation_PointX = x1
        self.Rotation_PointY = y1
        self.Tail1X = x2
        self.Tail1Y = y2
        self.Tail2X = x3
        self.Tail2Y = y3
        self.Tail3X = x4
        self.Tail3Y = y4

    def attack_tail1(self,x,y):
        if self.Tail1X == x and self.Tail1Y == y:
          return True
        else:
           return False

    def attack_tail2(self,x,y):
        if self.Tail2X == x and self.Tail2Y == y:
          return True
        else:
           return False

    def attack_tail3(self,x,y):
        if self.Tail3X == x and self.Tail3Y == y:
          return True
        else:
           return False
        
class ship6(ship1):
    def __init__(self):
        super().__init__()
        self.Tail1X = -1
        self.Tail1Y = -1
        self.Tail2X = -1
        self.Tail2Y = -1
        self.Tail3X = -1
        self.Tail3Y = -1
        self.tail1 = 0
        self.tail2 = 0
        self.tail3 = 0

    def place_ship(self, x1, y1,x2,y2,x3,y3,x4,y4):
        self.Used = True
        self.Rotation_PointX = x1
        self.Rotation_PointY = y1
        self.Tail1X = x2
        self.Tail1Y = y2
        self.Tail2X = x3
        self.Tail2Y = y3
        self.Tail3X = x4
        self.Tail3Y = y4  
        
    def attack_tail1(self,x,y):
        if self.Tail1X == x and self.Tail1Y == y:
          return True
        else:
           return False

    def attack_tail2(self,x,y):
        if self.Tail2X == x and self.Tail2Y == y:
          return True
        else:
           return False

    def attack_tail3(self,x,y):
        if self.Tail3X == x and self.Tail3Y == y:
          return True
        else:
           return False
        
       

   
          

   



            
