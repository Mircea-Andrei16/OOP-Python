import ships
from time import sleep

class Grid:
    def __init__(self, number):
        self.rows_colums = number
        self.matrix = [['-']*number for n in range(number)]
        self.matrix_attack = [['-']*number for n in range(number)]
        self.ship1 = ships.ship1()
        self.ship2 = ships.ship2()
        self.ship3 = ships.ship3()
        self.ship4 = ships.ship4()
        self.ship5 = ships.ship5()
        self.ship6 = ships.ship6()
        self.positions = ships.ship_positions()
        self.points = 0
        self.ship_number = 0
        self.ship_destroyed = 0

    def in_grid(self,x,y):
        if x >=0 and x < self.rows_colums and y >= 0 and y < self.rows_colums:
            return True
        else:
            return False

    def place_ship(self):
        print("What type of ship you want to place?")
        print("You got 6 types of ships!")
        number = int(input("Type: "))
        if number == 1:
            print("Give the coordinates of the center point! Upper case Letter for row, number for column")
            a,b = input().split()
            a = ord(a) - ord('A')
            rot_x = int(a)
            rot_y = int(b)
            rot_y = rot_y -1
            if rot_x >= 0 and rot_x < self.rows_colums and rot_y >=0 and rot_y < self.rows_colums:
               if self.positions.in_array(rot_x,rot_y) == False:
                  if self.ship1.is_used() == 0:
                    self.positions.add_array(rot_x,rot_y)
                    self.ship1.place_ship(rot_x,rot_y)
                    self.matrix[rot_x][rot_y] = '*'
                  else:
                    print("The ship is already used!")
                    self.place_ship()
               else:
                   print("This cell is already used!")
                   self.place_ship()

            else:
                print("Incorrect coordinates!")
                self.place_ship()
        elif number == 5:
            print("Give the coordinates of the center point! Upper case Letter for row, number for column")
            a,b = input().split()
            a = ord(a) - ord('A')
            rot_x = int(a)
            rot_y = int(b)
            rot_y = rot_y -1
            if rot_x >= 0 and rot_x < self.rows_colums and rot_y >=0 and rot_y < self.rows_colums:
                if self.positions.in_array(rot_x,rot_y) == False and self.positions.in_array(rot_x,rot_y+1) == False and self.positions.in_array(rot_x+1,rot_y+1) == False and self.positions.in_array(rot_x+1,rot_y) == False:
                   if self.ship5.is_used() == 0:
                    if self.in_grid(rot_x,rot_y+1) == True and self.in_grid(rot_x+1,rot_y+1) == True and self.in_grid(rot_x+1,rot_y) == True:
                       self.ship5.place_ship(rot_x,rot_y,rot_x,rot_y+1,rot_x+1,rot_y+1,rot_x+1,rot_y)
                       self.positions.add_array(rot_x,rot_y)
                       self.positions.add_array(rot_x,rot_y+1)
                       self.positions.add_array(rot_x+1,rot_y+1)
                       self.positions.add_array(rot_x+1,rot_y)
                       self.matrix[rot_x][rot_y] = '*'
                       self.matrix[rot_x][rot_y+1] = '#'
                       self.matrix[rot_x+1][rot_y+1] = '#'
                       self.matrix[rot_x+1][rot_y] = '#'
                    else:
                        print("The ship leaves the grid!")
                        self.place_ship()
                   else:
                    print("The ship is already used!")
                    self.place_ship()
                else:
                    print("This cell is already used!")
                    self.place_ship()
            else:
                print("Incorrect coordinates!")
                self.place_ship()
        elif number == 2:
            print("Give the coordinates of the center point! Upper case Letter for row, number for column")
            a,b = input().split()
            a = ord(a) - ord('A')
            rot_x = int(a)
            rot_y = int(b)
            rot_y = rot_y -1
            if rot_x >= 0 and rot_x < self.rows_colums and rot_y >=0 and rot_y < self.rows_colums:
               if self.ship2.is_used() == 0:
                if self.positions.in_array(rot_x,rot_y) == False and self.positions.in_array(rot_x,rot_y+1) == False:
                   if self.in_grid(rot_x,rot_y+1) == True:
                    self.matrix[rot_x][rot_y] = '*'
                    self.matrix[rot_x][rot_y+1] = '#'
                    self.print()
                    self.matrix[rot_x][rot_y+1] = '-'

                    ok = True
                    cycleR = 0
                    cycleL = 3
                    x = rot_x
                    y = rot_y+1

                    while ok:
                        ans = input("Do you want to rotate the ship?'Y' for YES/ 'N' for NO ")
                        if ans == "N":
                            ok = False
                        else:
                            ans2 = input("Left or Right? 'L' for Left/ 'R' for Right ")

                            if (ans2 == "R" and cycleR == 0) or (ans2 == "L" and cycleL == 3):
                              if ans2 =="R": 
                               if self.in_grid(rot_x+1,rot_y) == True and self.positions.in_array(rot_x+1,rot_y):
                                 self.matrix[rot_x+1][rot_y] = '#'
                                 self.print()
                                 self.matrix[rot_x+1][rot_y] = '-'
                                 x = rot_x+1
                                 y = rot_y
                                 cycleL = 2
                                 cycleR = 1
                              else:
                                if self.in_grid(rot_x-1,rot_y) == True and self.positions.in_array(rot_x-1,rot_y):
                                 self.matrix[rot_x-1][rot_y] = '#'
                                 self.print()
                                 self.matrix[rot_x-1][rot_y] = '-'
                                 x = rot_x-1
                                 y = rot_y
                                 cycleL = 0
                                 cycleR = 3
                        
                            elif (ans2 == "R" and cycleR == 1) or (ans2 == "L" and cycleL == 2):
                               if ans2 =="R": 
                                if self.in_grid(rot_x,rot_y-1) == True and self.positions.in_array(rot_x,rot_y -1):
                                 self.matrix[rot_x][rot_y-1] = '#'
                                 self.print()
                                 self.matrix[rot_x][rot_y-1] = '-'
                                 x = rot_x
                                 y = rot_y-1
                                 cycleL = 1
                                 cycleR = 2
                               else:
                                 self.matrix[rot_x][rot_y + 1] = '#'
                                 self.print()
                                 self.matrix[rot_x][rot_y + 1] = '-'
                                 x = rot_x
                                 y = rot_y + 1
                                 cycleL = 3
                                 cycleR = 0
                   
                            elif (ans2 == "R" and cycleR == 2) or (ans2 == "L" and cycleL == 1):
                              if ans2 == "R": 
                               if self.in_grid(rot_x-1,rot_y) == True and self.positions.in_array(rot_x-1,rot_y):
                                 self.matrix[rot_x-1][rot_y] = '#'
                                 self.print()
                                 self.matrix[rot_x-1][rot_y] ='-'
                                 x = rot_x-1
                                 y = rot_y
                                 cycleL = 0
                                 cycleR = 3
                              else:
                                if self.in_grid(rot_x+1,rot_y) == True and self.positions.in_array(rot_x+1,rot_y):
                                 self.matrix[rot_x+1][rot_y] = '#'
                                 self.print()
                                 self.matrix[rot_x+1][rot_y] = '-'
                                 x = rot_x+1
                                 y = rot_y
                                 cycleL = 2
                                 cycleR = 1

                            elif (ans2 == "R" and cycleR == 3) or (ans2 =="L" and cycleL == 0):
                               if ans2 =="R":  
                                 self.matrix[rot_x][rot_y + 1] = '#'
                                 self.print()
                                 self.matrix[rot_x][rot_y + 1] = '-'
                                 x = rot_x
                                 y = rot_y + 1
                                 cycleL = 3
                                 cycleR = 0
                               else:
                                 if self.in_grid(rot_x,rot_y-1) == True and self.positions.in_array(rot_x,rot_y - 1):
                                  self.matrix[rot_x][rot_y-1] = '#'
                                  self.print()
                                  self.matrix[rot_x][rot_y-1] = '-'
                                  x = rot_x
                                  y = rot_y-1
                                  cycleL = 1
                                  cycleR = 2
                    self.positions.add_array(rot_x,rot_y)
                    self.positions.add_array(x,y)
                    self.ship2.place_ship(rot_x,rot_y,x,y)
                    self.matrix[x][y] = '#'
                   else:
                       print("Can not be in the field!\n")
                       self.place_ship()
                else:
                    print("The cells are already used\n")
                    self.place_ship()
               else:
                    print("The ship is already used!\n")
                    self.place_ship()
            else:
                print("Incorrect coordinates!\n")
                self.place_ship()
        elif number == 4:
            print("Give the coordinates of the center point! Upper case Letter for row, number for column")
            a,b = input().split()
            a = ord(a) - ord('A')
            rot_x = int(a)
            rot_y = int(b)
            rot_y = rot_y -1
            if rot_x >= 0 and rot_x < self.rows_colums and rot_y >=0 and rot_y < self.rows_colums:
                if self.ship4.is_used() == 0:
                  if self.positions.in_array(rot_x,rot_y) == False and self.positions.in_array(rot_x+1,rot_y) == False and self.positions.in_array(rot_x,rot_y-1) == False:
                    if self.in_grid(rot_x+1,rot_y) == True and self.in_grid(rot_x,rot_y-1) == True:
                       self.matrix[rot_x][rot_y] = '*'
                       self.matrix[rot_x+1][rot_y] = '#'
                       self.matrix[rot_x][rot_y-1] = '#'
                       self.print()
                       self.matrix[rot_x+1][rot_y] = '-'
                       self.matrix[rot_x][rot_y-1] = '-'

                       ok = True
                       cycleR = 0
                       cycleL = 3
                       x1 = rot_x+1
                       x2 = rot_x
                       y1 = rot_y
                       y2 = rot_y-1
 
                       while ok:
                         ans = input("Do you want to rotate the ship?'Y' for YES/ 'N' for NO ")
                         if ans == "N":
                            ok = False
                         else:
                            ans2 = input("Left or Right? 'L' for Left/ 'R' for Right ")

                            if (ans2 == "R" and cycleR == 0) or (ans2 == "L" and cycleL == 3):
                              if ans2 =="R": 
                               if self.in_grid(rot_x-1,rot_y) == True and self.positions.in_array(rot_x-1,rot_y):
                                 self.matrix[rot_x][rot_y-1] = '#'
                                 self.matrix[rot_x-1][rot_y] = '#'
                                 self.print()
                                 self.matrix[rot_x][rot_y-1] = '-'
                                 self.matrix[rot_x-1][rot_y] = '-'
                                 x1 = rot_x
                                 x2 = rot_x-1
                                 y1 = rot_y-1
                                 y2 = rot_y
                                 cycleL = 2
                                 cycleR = 1
                              else:
                                if self.in_grid(rot_x,rot_y+1) == True and self.positions.in_array(rot_x,rot_y +1):
                                 self.matrix[rot_x+1][rot_y] = '#'
                                 self.matrix[rot_x][rot_y+1] = '#'
                                 self.print()
                                 self.matrix[rot_x+1][rot_y] = '-'
                                 self.matrix[rot_x][rot_y+1] = '-'
                                 x1 = rot_x+1
                                 x2 = rot_x
                                 y1 = rot_y
                                 y2 = rot_y+1
                                 cycleL = 0
                                 cycleR = 3
                        
                            elif (ans2 == "R" and cycleR == 1) or (ans2 == "L" and cycleL == 2):
                               if ans2 =="R": 
                                if self.in_grid(rot_x,rot_y+1) == True and self.positions.in_array(rot_x,rot_y+1):
                                 self.matrix[rot_x-1][rot_y] = '#'
                                 self.matrix[rot_x][rot_y+1] = '#'
                                 self.print()
                                 self.matrix[rot_x-1][rot_y] = '-'
                                 self.matrix[rot_x][rot_y+1] = '-'
                                 x1 = rot_x-1
                                 x2 = rot_x
                                 y1 = rot_y
                                 y2 = rot_y+1
                                 cycleL = 1
                                 cycleR = 2
                               else:
                                 self.matrix[rot_x+1][rot_y] = '#'
                                 self.matrix[rot_x][rot_y - 1] = '#'
                                 self.print()
                                 self.matrix[rot_x+1][rot_y] = '-'
                                 self.matrix[rot_x][rot_y -1] = '-'
                                 x1 = rot_x+1
                                 x2 = rot_x
                                 y1 = rot_y 
                                 y2 = rot_y - 1
                                 cycleL = 3
                                 cycleR = 0
                   
                            elif (ans2 == "R" and cycleR == 2) or (ans2 == "L" and cycleL == 1):
                              if ans2 == "R": 
                                 self.matrix[rot_x+1][rot_y] = '#'
                                 self.matrix[rot_x][rot_y+1] = '#'
                                 self.print()
                                 self.matrix[rot_x+1][rot_y] = '-'
                                 self.matrix[rot_x][rot_y+1] = '-'
                                 x1 = rot_x+1
                                 x2 = rot_x
                                 y1 =rot_y
                                 y2 = rot_y+1
                                 cycleL = 0
                                 cycleR = 3
                              else:
                                if self.in_grid(rot_x,rot_y-1) == True and self.positions.in_array(rot_x,rot_y-1):
                                 self.matrix[rot_x][rot_y-1] = '#'
                                 self.matrix[rot_x-1][rot_y] = '#'
                                 self.print()
                                 self.matrix[rot_x][rot_y-1] = '-'
                                 self.matrix[rot_x-1][rot_y] ='-'
                                 x1 = rot_x 
                                 x2 = rot_x -1
                                 y1 = rot_y -1
                                 y2 = rot_y
                                 cycleL = 2
                                 cycleR = 1

                            elif (ans2 == "R" and cycleR == 3) or (ans2 =="L" and cycleL == 0):
                               if ans2 =="R":  
                                 self.matrix[rot_x+1][rot_y] = '#'
                                 self.matrix[rot_x][rot_y -1] = '#'
                                 self.print()
                                 self.matrix[rot_x+1][rot_y] = '-'
                                 self.matrix[rot_x][rot_y -1] = '-'
                                 x1 = rot_x+1
                                 x2 = rot_x
                                 y1 = rot_y 
                                 y2 = rot_y-1
                                 cycleL = 3
                                 cycleR = 0
                               else:
                                 if self.in_grid(rot_x-1,rot_y) == True and self.positions.in_array(rot_x-1,rot_y):
                                  self.matrix[rot_x][rot_y+1] = '#'
                                  self.matrix[rot_x-1][rot_y] = '#'
                                  self.print()
                                  self.matrix[rot_x][rot_y+1] = '-'
                                  self.matrix[rot_x-1][rot_y] = '-'
                                  x1 = rot_x
                                  x2 = rot_x-1
                                  y1 = rot_y+1
                                  y2 = rot_y
                                  cycleL = 1
                                  cycleR = 2   
                                  
                       self.positions.add_array(rot_x,rot_y)
                       self.positions.add_array(x1,y1)
                       self.positions.add_array(x2,y2)
                       self.ship4.place_ship(rot_x,rot_y,x1,y1,x2,y2)
                       self.matrix[x1][y1] = '#'
                       self.matrix[x2][y2] = '#'
                    else:
                        print("Can not be in the field\n")
                        self.place_ship()
                  else:
                      print("The cells are already used\n")
                      self.place_ship()
                else:
                    print("The ship is already used!\n")
                    self.place_ship()
            else:
                print("Incorrect coordinates!\n")
                self.place_ship()
        elif number == 3:
            print("Give the coordinates of the center point! Upper case Letter for row, number for column")
            a,b = input().split()
            a = ord(a) - ord('A')
            rot_x = int(a)
            rot_y = int(b)
            rot_y = rot_y -1
            if rot_x >= 0 and rot_x < self.rows_colums and rot_y >=0 and rot_y < self.rows_colums:
                if self.ship3.is_used() == 0:
                  if self.positions.in_array(rot_x,rot_y) == False and self.positions.in_array(rot_x,rot_y+1) == False and self.positions.in_array(rot_x,rot_y+1) == False:
                    if self.in_grid(rot_x,rot_y+1) == True and self.in_grid(rot_x,rot_y+1) == True:
                       self.matrix[rot_x][rot_y] = '*'
                       self.matrix[rot_x][rot_y+1] = '#'
                       self.matrix[rot_x][rot_y+2] = '#'
                       self.print()
                       self.matrix[rot_x][rot_y+1] = '-'
                       self.matrix[rot_x][rot_y+2] = '-'

                       ok = True
                       cycleR = 0
                       cycleL = 3
                       x1 = rot_x
                       x2 = rot_x
                       y1 = rot_y+1
                       y2 = rot_y+2
 
                       while ok:
                         ans = input("Do you want to rotate the ship?'Y' for YES/ 'N' for NO ")
                         if ans == "N":
                            ok = False
                         else:
                            ans2 = input("Left or Right? 'L' for Left/ 'R' for Right ")

                            if (ans2 == "R" and cycleR == 0) or (ans2 == "L" and cycleL == 3):
                              if ans2 =="R": 
                               if self.in_grid(rot_x+1,rot_y) == True and self.in_grid(rot_x+2,rot_y) == True and self.positions.in_array(rot_x+1,rot_y) and self.positions.in_array(rot_x+2,rot_y):
                                 self.matrix[rot_x+1][rot_y] = '#'
                                 self.matrix[rot_x+2][rot_y] = '#'
                                 self.print()
                                 self.matrix[rot_x+1][rot_y] = '-'
                                 self.matrix[rot_x+2][rot_y] = '-'
                                 x1 = rot_x+1
                                 x2 = rot_x+2
                                 y1 = rot_y
                                 y2 = rot_y
                                 cycleL = 2
                                 cycleR = 1
                              else:
                                if self.in_grid(rot_x-1,rot_y) == True and self.in_grid(rot_x-2,rot_y) == True and self.positions.in_array(rot_x-1,rot_y) and self.positions.in_array(rot_x-2,rot_y):
                                 self.matrix[rot_x-1][rot_y] = '#'
                                 self.matrix[rot_x-2][rot_y] = '#'
                                 self.print()
                                 self.matrix[rot_x-1][rot_y] = '-'
                                 self.matrix[rot_x-2][rot_y] = '-'
                                 x1 = rot_x-1
                                 x2 = rot_x-2
                                 y1 = rot_y
                                 y2 = rot_y
                                 cycleL = 0
                                 cycleR = 3
                        
                            elif (ans2 == "R" and cycleR == 1) or (ans2 == "L" and cycleL == 2):
                               if ans2 =="R": 
                                if self.in_grid(rot_x,rot_y-1) == True and self.in_grid(rot_x,rot_y-2) == True and self.positions.in_array(rot_x,rot_y-1) and self.positions.in_array(rot_x,rot_y-2):
                                 self.matrix[rot_x][rot_y-1] = '#'
                                 self.matrix[rot_x][rot_y-2] = '#'
                                 self.print()
                                 self.matrix[rot_x][rot_y-1] = '-'
                                 self.matrix[rot_x][rot_y-2] = '-'
                                 x1 = rot_x
                                 x2 = rot_x
                                 y1 = rot_y-1
                                 y2 = rot_y-2
                                 cycleL = 1
                                 cycleR = 2
                               else:
                                 self.matrix[rot_x][rot_y + 1] = '#'
                                 self.matrix[rot_x][rot_y + 2] = '#'
                                 self.print()
                                 self.matrix[rot_x][rot_y + 1] = '-'
                                 self.matrix[rot_x][rot_y + 2] = '-'
                                 x1 = rot_x
                                 x2 = rot_x
                                 y1 = rot_y + 1
                                 y2 = rot_y + 1
                                 cycleL = 3
                                 cycleR = 0
                   
                            elif (ans2 == "R" and cycleR == 2) or (ans2 == "L" and cycleL == 1):
                              if ans2 == "R": 
                               if self.in_grid(rot_x-1,rot_y) == True and self.in_grid(rot_x-2,rot_y) == True and self.positions.in_array(rot_x-1,rot_y) and self.positions.in_array(rot_x-2,rot_y):
                                 self.matrix[rot_x-1][rot_y] = '#'
                                 self.matrix[rot_x-2][rot_y] = '#'
                                 self.print()
                                 self.matrix[rot_x-1][rot_y] = '-'
                                 self.matrix[rot_x-2][rot_y] = '-'
                                 x1 = rot_x-1
                                 x2 = rot_x-2
                                 y1 =rot_y
                                 y2 = rot_y
                                 cycleL = 0
                                 cycleR = 3
                              else:
                                if self.in_grid(rot_x+1,rot_y) == True and self.in_grid(rot_x+2,rot_y) == True and self.positions.in_array(rot_x+1,rot_y) and self.positions.in_array(rot_x+2,rot_y):
                                 self.matrix[rot_x+1][rot_y] = '#'
                                 self.matrix[rot_x+2][rot_y] = '#'
                                 self.print()
                                 self.matrix[rot_x+1][rot_y] = '-'
                                 self.matrix[rot_x+2][rot_y] = '-'
                                 x1 = rot_x + 1
                                 x2 = rot_x + 2
                                 y1 = rot_y
                                 y2 = rot_y
                                 cycleL = 2
                                 cycleR = 1

                            elif (ans2 == "R" and cycleR == 3) or (ans2 =="L" and cycleL == 0):
                               if ans2 =="R":  
                                 self.matrix[rot_x][rot_y + 1] = '#'
                                 self.matrix[rot_x][rot_y + 2] = '#'
                                 self.print()
                                 self.matrix[rot_x][rot_y + 1] = '-'
                                 self.matrix[rot_x][rot_y + 2] = '-'
                                 x1 = rot_x
                                 x2 = rot_x
                                 y1 = rot_y + 1
                                 y2 = rot_y + 2
                                 cycleL = 3
                                 cycleR = 0
                               else:
                                 if self.in_grid(rot_x,rot_y-1) == True and self.in_grid(rot_x,rot_y-2) == True and self.positions.in_array(rot_x,rot_y-1) and self.positions.in_array(rot_x,rot_y-2):
                                  self.matrix[rot_x][rot_y-1] = '#'
                                  self.matrix[rot_x][rot_y-2] = '#'
                                  self.print()
                                  self.matrix[rot_x][rot_y-1] = '-'
                                  self.matrix[rot_x][rot_y-2] = '-'
                                  x1 = rot_x
                                  x2 = rot_x
                                  y1 = rot_y-1
                                  y2 = rot_y-2
                                  cycleL = 1
                                  cycleR = 2   
                                  
                       self.positions.add_array(rot_x,rot_y)
                       self.positions.add_array(x1,y1)
                       self.positions.add_array(x2,y2)
                       self.ship3.place_ship(rot_x,rot_y,x1,y1,x2,y2)
                       self.matrix[x1][y1] = '#'
                       self.matrix[x2][y2] = '#'
                    else:
                        print("Can not be in the field!\n")
                        self.place_ship()
                  else:
                      print("The cells are already used\n")
                      self.place_ship()
                else:
                    print("The ship is already used!\n")
                    self.place_ship()
            else:
                print("Incorrect coordinates!\n")
                self.place_ship()
        elif number == 6:
            print("Give the coordinates of the center point! Upper case Letter for row, number for column")
            a,b = input().split()
            a = ord(a) - ord('A')
            rot_x = int(a)
            rot_y = int(b)
            rot_y = rot_y -1
            if rot_x >= 0 and rot_x < self.rows_colums and rot_y >=0 and rot_y < self.rows_colums:
                if self.ship6.is_used() == 0:
                  if self.positions.in_array(rot_x,rot_y) == False and self.positions.in_array(rot_x,rot_y+1) == False and self.positions.in_array(rot_x,rot_y-1) == False and self.positions.in_array(rot_x-1,rot_y) == False:
                    if self.in_grid(rot_x,rot_y+1) == True and self.in_grid(rot_x,rot_y-1) == True and self.in_grid(rot_x-1,rot_y) == True:
                       self.matrix[rot_x][rot_y] = '*'
                       self.matrix[rot_x][rot_y+1] = '#'
                       self.matrix[rot_x][rot_y-1] = '#'
                       self.matrix[rot_x-1][rot_y] = '#'
                       self.print()
                       self.matrix[rot_x+1][rot_y] = '-'
                       self.matrix[rot_x][rot_y-1] = '-'
                       self.matrix[rot_x-1][rot_y] = '-'

                       ok = True
                       cycleR = 0
                       cycleL = 3
                       x1 = rot_x
                       x2 = rot_x
                       x3 = rot_x-1
                       y1 = rot_y+1
                       y2 = rot_y-1
                       y3 = rot_y
 
                       while ok:
                         ans = input("Do you want to rotate the ship?'Y' for YES/ 'N' for NO ")
                         if ans == "N":
                            ok = False
                         else:
                            ans2 = input("Left or Right? 'L' for Left/ 'R' for Right ")

                            if (ans2 == "R" and cycleR == 0) or (ans2 == "L" and cycleL == 3):
                              if ans2 =="R": 
                               if self.in_grid(rot_x+1,rot_y) == True and self.positions.in_array(rot_x+1,rot_y):
                                 self.matrix[rot_x+1][rot_y] = '#'
                                 self.matrix[rot_x-1][rot_y] = '#'
                                 self.matrix[rot_x][rot_y+1] = '#'
                                 self.print()
                                 self.matrix[rot_x+1][rot_y] = '-'
                                 self.matrix[rot_x-1][rot_y] = '-'
                                 self.matrix[rot_x][rot_y+1] = '-'
                                 x1 = rot_x+1
                                 x2 = rot_x-1
                                 x3 = rot_x
                                 y1 = rot_y
                                 y2 = rot_y
                                 y3 = rot_y+1
                                 cycleL = 2
                                 cycleR = 1
                              else:
                                if self.in_grid(rot_x+1,rot_y) == True and self.positions.in_array(rot_x+1,rot_y):
                                 self.matrix[rot_x+1][rot_y] = '#'
                                 self.matrix[rot_x-1][rot_y] = '#'
                                 self.matrix[rot_x][rot_y-1] = '#'
                                 self.print()
                                 self.matrix[rot_x+1][rot_y] = '-'
                                 self.matrix[rot_x-1][rot_y] = '-'
                                 self.matrix[rot_x][rot_y-1] = '-'
                                 x1 = rot_x+1
                                 x2 = rot_x-1
                                 x3 =rot_x
                                 y1 = rot_y
                                 y2 = rot_y
                                 y3 = rot_y-1
                                 cycleL = 0
                                 cycleR = 3
                        
                            elif (ans2 == "R" and cycleR == 1) or (ans2 == "L" and cycleL == 2):
                               if ans2 =="R": 
                                if self.in_grid(rot_x,rot_y-1) == True and self.positions.in_array(rot_x,rot_y-1):
                                 self.matrix[rot_x][rot_y+1] = '#'
                                 self.matrix[rot_x][rot_y-1] = '#'
                                 self.matrix[rot_x+1][rot_y] = '#'
                                 self.print()
                                 self.matrix[rot_x][rot_y+1] ='-'
                                 self.matrix[rot_x][rot_y-1] = '-'
                                 self.matrix[rot_x+1][rot_y] = '-'
                                 x1 = rot_x
                                 x2 = rot_x
                                 x3 = rot_x+1
                                 y1 = rot_y+1
                                 y2 = rot_y-1
                                 y3=  rot_y
                                 cycleL = 1
                                 cycleR = 2
                               else:
                                 self.matrix[rot_x][rot_y-1] = '#'
                                 self.matrix[rot_x][rot_y + 1] = '#'
                                 self.matrix[rot_x-1][rot_y] = '#'
                                 self.print()
                                 self.matrix[rot_x][rot_y-1] = '-'
                                 self.matrix[rot_x][rot_y + 1] = '-'
                                 self.matrix[rot_x-1][rot_y] = '-'
                                 x1 = rot_x
                                 x2 = rot_x
                                 x3 = rot_y-1
                                 y1 = rot_y -1
                                 y2 = rot_y + 1
                                 y3 = rot_y
                                 cycleL = 3
                                 cycleR = 0
                   
                            elif (ans2 == "R" and cycleR == 2) or (ans2 == "L" and cycleL == 1):
                              if ans2 == "R": 
                                 self.matrix[rot_x+1][rot_y] = '#'
                                 self.matrix[rot_x-1][rot_y] = '#'
                                 self.matrix[rot_x][rot_y-1] = '#'
                                 self.print()
                                 self.matrix[rot_x+1][rot_y] = '-'
                                 self.matrix[rot_x-1][rot_y] = '-'
                                 self.matrix[rot_x][rot_y-1] = '-'
                                 x1 = rot_x+1
                                 x2 = rot_x-1
                                 x3 = rot_x
                                 y1 =rot_y
                                 y2 = rot_y
                                 y3 = rot_y-1
                                 cycleL = 0
                                 cycleR = 3
                              else:
                                 self.matrix[rot_x+1][rot_y] = '#'
                                 self.matrix[rot_x-1][rot_y] = '#'
                                 self.matrix[rot_x][rot_y+1] = '#'
                                 self.print()
                                 self.matrix[rot_x+1][rot_y] = '-'
                                 self.matrix[rot_x-1][rot_y] = '-'
                                 self.matrix[rot_x][rot_y+1] = '-'
                                 x1 = rot_x+1
                                 x2 = rot_x-1
                                 x3 = rot_x
                                 y1 =rot_y
                                 y2 = rot_y
                                 y3 = rot_y+1
                                 cycleL = 2
                                 cycleR = 1

                            elif (ans2 == "R" and cycleR == 3) or (ans2 =="L" and cycleL == 0):
                               if ans2 =="R":  
                                 self.matrix[rot_x-1][rot_y] = '#'
                                 self.matrix[rot_x][rot_y -1] = '#'
                                 self.matrix[rot_x][rot_y +1] = '#'
                                 self.print()
                                 self.matrix[rot_x-1][rot_y] = '-'
                                 self.matrix[rot_x][rot_y -1] = '-'
                                 self.matrix[rot_x][rot_y +1] = '-'
                                 x1 = rot_x-1
                                 x2 = rot_x
                                 x3 = rot_x
                                 y1 = rot_y 
                                 y2 = rot_y-1
                                 y3 = rot_y+1
                                 cycleL = 3
                                 cycleR = 0
                               else:
                                 if self.in_grid(rot_x-1,rot_y) == True and self.positions.in_array(rot_x-1,rot_y):
                                  self.matrix[rot_x][rot_y+1] = '#'
                                  self.matrix[rot_x][rot_y-1] = '#'
                                  self.matrix[rot_x+1][rot_y] = '#'
                                  self.print()
                                  self.matrix[rot_x][rot_y+1] = '-'
                                  self.matrix[rot_x][rot_y-1] = '-'
                                  self.matrix[rot_x+1][rot_y] = '-'
                                  x1 = rot_x
                                  x2 = rot_x
                                  x3 = rot_x+1
                                  y1 = rot_y+1
                                  y2 = rot_y-1
                                  y3 = rot_y 
                                  cycleL = 1
                                  cycleR = 2   
                                  
                       self.positions.add_array(rot_x,rot_y)
                       self.positions.add_array(x1,y1)
                       self.positions.add_array(x2,y2)
                       self.positions.add_array(x3,y3)
                       self.ship6.place_ship(rot_x,rot_y,x1,y1,x2,y2,x3,y3)
                       self.matrix[x1][y1] = '#'
                       self.matrix[x2][y2] = '#'
                       self.matrix[x3][y3] = '#'
                    else:
                        print("Can not be in the field!\n")
                        self.place_ship()
                  else:
                      print("The cells are already used\n")
                      self.place_ship()
                else:
                    print("The ship is already used!\n")
                    self.place_ship()
            else:
                print("Incorrect coordinates!\n")
                self.place_ship()

    def print(self):
       aux = 'A'
       print(end="  ")
       for n in range(self.rows_colums):
           print(n+1,end=" ")
       print()
       for i in range(self.rows_colums):
           print(aux,end=" ")
           for j in range(self.rows_colums):
               print(self.matrix[i][j],end=" ")
           print()
           aux = chr(ord(aux)+1)

    def print1(self):
       aux = 'A'
       print(end="  ")
       for n in range(self.rows_colums):
           print(n+1,end=" ")
       print()
       for i in range(self.rows_colums):
           print(aux,end=" ")
           for j in range(self.rows_colums):
               print(self.matrix_attack[i][j],end=" ")
           print()
           aux = chr(ord(aux)+1)

    def Choose_ship(self,ship_number):
        self.print()
        self.ship_number = ship_number
        while ship_number:
            print("You got left ",ship_number," ships!")
            self.place_ship()
            self.print()
            sleep(2)
            ship_number = ship_number -1

    def attack(self):
        self.print1()
        print("Give the coordinates of the attack!")
        a,b = input().split()
        a = ord(a) - ord('A')
        x = int(a)
        y = int(b)
        y = y - 1
        if self.ship1.is_used() == True:
            if self.ship1.attack(x,y) == True:
                self.points = self.points + 100
                self.matrix_attack[x][y] = '*'
                self.print1()
                print("POINTS: ",self.points)
                self.ship_destroyed = self.ship_destroyed +1
                if self.ship_destroyed == self.ship_number:
                    return 1
                return 0
        if self.ship2.is_used() == True:
            if self.ship2.attack(x,y) == True:
                self.matrix_attack[x][y] = '*'
                self.matrix_attack[self.ship2.Tail1X][self.ship2.Tail1Y] = '#'
                self.print1()
                if self.ship2.tail == True:
                    self.points = self.points + 200
                else:
                    self.points= self.points + 100
                print("POINTS: ",self.points)
                self.ship_destroyed = self.ship_destroyed +1
                if self.ship_destroyed == self.ship_number:
                    return 1
                return 0
                
            if self.ship2.attack_tail(x,y) == True:
                self.matrix_attack[x][y] = 'b'
                self.points= self.points + 100
                self.ship2.tail = False
                self.print1()
                print("POINTS: ",self.points)
                return 0
        if self.ship3.is_used() == True:
             if self.ship3.attack(x,y) == True:
                self.matrix_attack[x][y] = '*'
                self.matrix_attack[self.ship3.Tail1X][self.ship3.Tail1Y] = '#'
                self.matrix_attack[self.ship3.Tail2X][self.ship3.Tail2Y] = '#'
                self.print1()
                if self.ship3.tail1 == True and self.ship3.tail2 == True:
                    self.points = self.points + 300
                elif self.ship3.tail1 == True or self.ship3.tail2 == True:
                    self.points= self.points + 200
                elif self.ship3.tail1 == False and self.ship3.tail2 == False:
                    self.points= self.points + 100
                print("POINTS: ",self.points)
                self.ship_destroyed = self.ship_destroyed +1
                if self.ship_destroyed == self.ship_number:
                    return 1
                return 0
             if self.ship3.attack_tail1(x,y) == True:
                self.matrix_attack[x][y] = 'b'
                self.points= self.points + 100
                self.ship3.tail1 = False
                self.print1()
                print("POINTS: ",self.points)
                return 0
             if self.ship3.attack_tail2(x,y) == True:
                self.matrix_attack[x][y] = 'b'
                self.points= self.points + 100
                self.ship3.tail1 = False
                self.print1()
                print("POINTS: ",self.points)
                return 0
        if self.ship4.is_used() == True:
             if self.ship4.attack(x,y) == True:
                self.matrix_attack[x][y] = '*'
                self.matrix_attack[self.ship4.Tail1X][self.ship4.Tail1Y] = '#'
                self.matrix_attack[self.ship4.Tail2X][self.ship4.Tail2Y] = '#'
                self.print1()
                if self.ship4.tail1 == True and self.ship4.tail2 == True:
                    self.points = self.points + 300
                elif self.ship4.tail1 == True or self.ship4.tail2 == True:
                    self.points= self.points + 200
                elif self.ship4.tail1 == False and self.ship4.tail2 == False:
                    self.points= self.points + 100
                print("POINTS: ",self.points)
                return 0
             if self.ship4.attack_tail1(x,y) == True:
                self.matrix_attack[x][y] = 'b'
                self.points= self.points + 100
                self.ship4.tail1 = False
                self.print1()
                print("POINTS: ",self.points)
                self.ship_destroyed = self.ship_destroyed +1
                if self.ship_destroyed == self.ship_number:
                    return 1
                return 0
             if self.ship4.attack_tail2(x,y) == True:
                self.matrix_attack[x][y] = 'b'
                self.points= self.points + 100
                self.ship4.tail2 = False
                self.print1()
                print("POINTS: ",self.points)
                return 0
        if self.ship5.is_used() == True:
             if self.ship5.attack(x,y) == True:
                self.matrix_attack[x][y] = '*'
                self.matrix_attack[self.ship5.Tail1X][self.ship5.Tail1Y] = '#'
                self.matrix_attack[self.ship5.Tail2X][self.ship5.Tail2Y] = '#'
                self.matrix_attack[self.ship5.Tail3X][self.ship5.Tail3Y] = '#'
                self.print1()
                x = self.ship5.tail1 + self.ship5.tail2 + self.ship5.tail3
                if x == 0:
                    self.points = self.points + 400
                elif x ==2:
                    self.points = self.points + 300
                elif x == 1:
                    self.points = self.points + 200
                elif x == 3:
                     self.points = self.points + 100
                print("POINTS: ",self.points)
                self.ship_destroyed = self.ship_destroyed +1
                if self.ship_destroyed == self.ship_number:
                    return 1
                return 0
             if self.ship5.attack_tail1(x,y) == True:
                self.matrix_attack[x][y] = 'b'
                self.points= self.points + 100
                self.ship5.tail1 = 1
                self.print1()
                print("POINTS: ",self.points)
                return 0
             if self.ship5.attack_tail2(x,y) == True:
                self.matrix_attack[x][y] = 'b'
                self.points= self.points + 100
                self.ship5.tail2 = 1
                self.print1()
                print("POINTS: ",self.points)
                return 0
             if self.ship5.attack_tail3(x,y) == True:
                self.matrix_attack[x][y] = 'b'
                self.points= self.points + 100
                self.ship5.tail3 = 1
                self.print1()
                print("POINTS: ",self.points)
                return 0
        if self.ship6.is_used() == True:
             if self.ship6.attack(x,y) == True:
                self.matrix_attack[x][y] = '*'
                self.matrix_attack[self.ship6.Tail1X][self.ship6.Tail1Y] = '#'
                self.matrix_attack[self.ship6.Tail2X][self.ship6.Tail2Y] = '#'
                self.matrix_attack[self.ship6.Tail3X][self.ship6.Tail3Y] = '#'
                self.print1()
                x = self.ship6.tail1 + self.ship6.tail2 + self.ship6.tail3
                if x == 0:
                    self.points = self.points + 400
                elif x ==2:
                    self.points = self.points + 300
                elif x == 1:
                    self.points = self.points + 200
                elif x == 3:
                     self.points = self.points + 100
                print("POINTS: ",self.points)
                return 0
             if self.ship6.attack_tail1(x,y) == True:
                self.matrix_attack[x][y] = 'b'
                self.points= self.points + 100
                self.ship6.tail1 = 1
                self.print1()
                print("POINTS: ",self.points)
                self.ship_destroyed = self.ship_destroyed +1
                if self.ship_destroyed == self.ship_number:
                    return 1
                return 0
             if self.ship6.attack_tail2(x,y) == True:
                self.matrix_attack[x][y] = 'b'
                self.points= self.points + 100
                self.ship6.tail2 = 1
                self.print1()
                print("POINTS: ",self.points)
                return 0
             if self.ship6.attack_tail3(x,y) == True:
                self.matrix_attack[x][y] = 'b'
                self.points= self.points + 100
                self.ship6.tail3 = 1
                self.print1()
                print("POINTS: ",self.points)
                return 0
        self.matrix_attack[x][y] = 'r'
        self.points = self.points - 50
        self.print1()
        print("POINTS :", self.points)
        return 0


                

                

                





  




        
