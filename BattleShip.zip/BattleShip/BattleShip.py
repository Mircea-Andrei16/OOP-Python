import grid
from time import sleep
def main(): ## main function that calls the menu function continnously
   while(1):
       stop_menu = menu()
       if(stop_menu == 0): 
           break     

def menu():
   print("BattleShip".center(50,'='))

   choice = input("""   Main Menu
1.Play the game with a friend
2.Help
3.Exit\n""")

   if choice == "1":
     print("\n"*40)
     print("""
  Please choose the size of the of the board of the game! For a interactive game 
we suggest to use a board smaller than 10. The maximum size is 26!\n""")
     a = int(input("Choose the number: "))
     while a >26 or a <= 1:
         print("Choose a good number")
         a = int(input())

     Player1 = grid.Grid(a)
     Player2 = grid.Grid(a)

     print("Choose the number of ships you want to put in the battlefield!.The maximum number is 6!")
     ships_number = int(input("Choose the number of ships: "))
     while ships_number >6 or ships_number < 1:
         print("Choose a good number")
         ships_number = int(input())
     print("Now the first player chooses his ships!")
     Player1.Choose_ship(ships_number)
     print("\n"*50)
     print("Now the second player chooses his ships!")
     Player2.Choose_ship(ships_number)
     print("\n"*50)
     game = True
     while game:
      print("First player attacks")
      g1 = Player2.attack()
      print("\n"*10)
      print("Second player attacks")
      g2 = Player1.attack()
      if g1 == 1:
          print("First player wins!!")
          sleep(2)
          break
      if g2 == 1:
          print("Second player wins!!")
          sleep(2)
          break
   elif choice == "2":
    print("""This is a game about destorying ships from one table to another!
    The basic functions are that when you want to place a  ship you have to give the coordinates 
    of the center of movement of the ship.
    If you want to rotate a ship you have to press "Y" for yes and "N" for no than "L" for a left rotation
    and "R" for a right rotation""")
    print("\n"*10)
   elif choice == "3":
    print("Goodbye!")
    return 0


main()
