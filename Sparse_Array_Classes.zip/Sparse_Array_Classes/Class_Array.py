
class Sparse_Array:
    def __init__(self): ##default constructor for initialise the list of the elements, the dimenisons and
        self.Array = [] ## the number of the elements in the list
        self.height = 0
        self.lenght = 0
        self.witdh = 0
        self.no_elements = 0

    def get_no_elements(self): ##getter for number of elements in the list
         return self.no_elements

    def append(self,a):   ##setter to put elements in the list  
        self.Array.append(a)

    def Create_Array(self,f):            
            lines_list = f.readlines() ## variable lines_list take all the lines from the txt file
            lenght, width, height, no_elements = (int(val) for val in lines_list[0].split()) ##read the first line
            ##in the first the line are the dimensions of the the sparse array and the number of the elements that 
            # are in the file
            self.lenght = lenght                            
            self.witdh = width                            
            self.height = height
            self.no_elements = no_elements
            ##put the dimenison and the number of elements in the values of the class
            for i in range(0,no_elements): 
                a = [] ## use an auxiliar list for storing from each line the elements 
                k,i,j,value = (float(val) for val in lines_list[i+1].split()) 
                k = int(k)                                                   
                i = int(i)                                                   
                j = int(j)
                a.append(k)       
                a.append(i)        
                a.append(j)        
                a.append(value)     
                self.append(a) ## add the element in the sparse array list  
            f.close()

    def Print_Elements(self):##function that prints the elements present in the sparse array
         print()
         print("Elements of the sparse matrix that arent null are:")
         print()
         for x in self.Array: ##iteratre trough the array and print element by element
             print(x)
         print()

    def Print_Dimension(self):##prints the dimensions of the sparse array
        print()
        print("The dimensions of the Array are: ")
        print()
        print("Lenght Width Height\n") 
        print("  ",self.lenght,"  ",self.height,"   ",self.witdh)

    def Read_Value(self):
         print()
         print("Give the indices of the specified element. The indices must be bigger than 0 or equal with 0")
         print("Please press enter after every idex")
         lenght_index = int(input())
         width_index = int(input()) 
         height_index = int(input()) 
          ## we read the indices from the keyboard
         if lenght_index >= self.lenght or width_index >= self.witdh or height_index >= self.height: 
              print("The indices given are bigger than the dimension of the array")        
              return                                                                            
        ##if the indices are too big, we semnalate that and exit the function

         n = self.no_elements 
         b = 0 ##helpfull variable that intarate inside an element for comparing the indices
          
         for a in range(0,n): 
             if self.Array[a][b] == lenght_index:   ##if we find that that the lenght indices are equal we go further
                 b += 1  
                 if self.Array[a][b] == width_index: #same here
                    b += 1
                    if self.Array[a][b] == height_index: # all indices corespond so we can print the element
                        b += 1 
                        print(self.Array[a][b]) 
                        return
                    else:
                        b = 0 # if we dont find the element we reset the variable for interation inside the element
                        continue
                 else:
                     b = 0 
                     continue
             else:
                 b = 0  
                 continue
    print("This element is not in the list") #if we iterate trough all elements and we dont find any element
                                             #with this indices we print this message 

    def Writing_Value(self): #functoin to add an element in the list if is possible
        
        total = self.lenght * self.witdh * self.height #this represent the number of the total elements in the array
        no_elements = self.no_elements
        
        procent = 1/total #this variable stores how much represent an element in the array
        procent = (procent) * (no_elements+1) #the procent held by the elements in the array  

        if procent >= 0.1:  #if that procent is bigger that 10% we can no longer add elements in the array
             print("The list is full!") 
             return
        #read the elements from the keyboard and sore them in an auxiliary list
        print("Give the indices and the value of the element. The indices must be bigger than 0 or equal with 0")
        print("Please press enter after every idex or the value")
        aux = []
        lenght_index = int(input())  
        width_index = int(input())
        height_index = int(input())
        print("Give the value of the element")
        print()
        val = float(input()) 
        if lenght_index >= self.lenght or width_index >= self.witdh or height_index >= self.height: 
            print("The indices given are bigger than the dimension of the array")        
            return        
        aux.append(lenght_index) 
        aux.append(width_index) 
        aux.append(height_index) 
        aux.append(val)

        b = 0 #variable that iteerate inside an element, helps to see where we have to add the element 
     
        for a in range(0,no_elements): #iterate through the elements
            if self.Array[a][b] > lenght_index: #if the first index is smaller than the first index of the current
                                                # element than we can add the new element in from of the current element
               if lenght_index == self.Array[a-1][0]  and width_index == self.Array[a-1][1] and height_index == self.Array[a-1][2]:
                   print("At this indexes already exists an element\nPlease introduct another indexes")
                   return
               #this if helps no to put 2 elements with the same indices in the array
               self.Array.insert(a,aux)
               self.no_elements += 1
               return
            elif self.Array[a][b] == lenght_index:# we go further to the nex index and apply the same algorithm above 
               b += 1 
               if self.Array[a][b] > width_index:
                  if lenght_index == self.Array[a-1][0]  and width_index == self.Array[a-1][1] and height_index == self.Array[a-1][2]:
                     print("At this indexes already exists an element\nPlease introduct another indexes")
                     return
                  self.Array.insert(a,aux)
                  self.no_elements += 1
                  return
               elif self.Array[a][b] == width_index:# we go to the last index and apply the algorithm
                     b += 1 
                     if self.Array[a][b] > height_index:
                        if lenght_index == self.Array[a-1][0]  and width_index == self.Array[a-1][1] and height_index == self.Array[a-1][2]:
                           print("At this indexes already exists an element\nPlease introduct another indexes")
                           return
                        self.Array.insert(a,aux)
                        self.no_elements += 1
                        return
            b = 0 #we reset the variable that iterates through the indices of the elements everytime we go further in the array
        
        if no_elements == len(self.Array): #if we reach the final of the array and doesnt put an element in the arrray
           self.append(aux)          #we add the element at the ened of the list
           self.no_elements += 1
           return
      
    def Verification_Merging(self,lenght1,width1,height1,lenght2,width2,height2):
        # function that compare indices of 2 elements from different arrays and retrun if 
        # one elemenent should be in front of the other or if the indices are eqaul
        # 1-> element1 is in front of element 2
        # 2-> element2 is in front of element 1
        # 3-> indices are equal
         if lenght1 < lenght2:  
            return 1 
         else: 
            if lenght1 > lenght2:
               return 2 
            if width1 < width2: 
               return 1
            else:
                if width1 > width2:
                   return 2
                if width1 < width2:
                   return 1
                else:
                    if height1 > height1:
                       return 2
                    return 3 

    def Add_2_Arrays(self,Example_Array):
        #if we have to add elements we need to be carefull not to add more than 10% of the capacity of the array
        total = self.lenght * self.witdh * self.height
        procent = 1/total
        number_elements = 0
        add = 0 # variables that tell if we add or substract
        substract = 0 #
        choice = input("""Do you want to add or to substract?
1.Add
2.Subtract
Please enter your choice: """)
        if choice == "1":
           add = 1
        if choice == "2":
           substract = 1
        Sum_Array = Sparse_Array() #create an empty sparse array for storing the final array 
        n = self.no_elements 
        m = Example_Array.get_no_elements()
        i = 0
        j = 0
        # we use the merging algorithm to resolve the addind or substracting
        while(i < n and j < m): 
             verif = self.Verification_Merging(self.Array[i][0],self.Array[i][1],self.Array[i][2],Example_Array.Array[j][0],Example_Array.Array[j][1],Example_Array.Array[j][2])
             # verif stores the idea which element should be add first or if we have to add or substract 
             # 2 elemnts
             if verif == 1: #if the element from array1 is smaller we add it first 
                v = procent * (number_elements+1) #verify if is space for storing the element
                if v >0.1:
                    break
                Sum_Array.append(self.Array[i]) #we add and go to the next element in the array1
                number_elements += 1
                i += 1 #go to the next element in the array1
             if verif == 2: #if the element from array1 is smaller we add it first 
                if add == 1:  #beacuse it the second operator we nned to know if is adding or substracting
                              # beacuse if is substraccting we have to changhe the sign
                   v = procent * (number_elements+1) #verify if is space for storing the element
                   if v >0.1:
                        break
                   Sum_Array.append(Example_Array.Array[j]) 
                   number_elements += 1
                else: #changind the sign
                    Example_Array.Array[j][3] = -Example_Array.Array[j][3]
                    v = procent * (number_elements+1)
                    if v >0.1:
                       break
                    Sum_Array.append(Example_Array.Array[j])
                    number_elements += 1
                    Example_Array.Array[j][3] = -Example_Array.Array[j][3]
                j += 1 
             if verif == 3:#if the indices are equal we have to add or substract the respective elements
                a = [] #use an auxilary list for storing the element that we add in the sum_array
                a.append(self.Array[j][0])
                a.append(self.Array[j][1])
                a.append(self.Array[j][2]) #add the indices
                if add == 1: #is is add we obviously adding
                   sum = self.Array[i][3] + Example_Array.Array[j][3] 
                   if sum != 0: #we veirfiy if the sum is not 0 because in the list are only non-null elements
                      a.append(sum)
                      v = procent * (number_elements+1) #verify if is space for storing the element
                      if v >0.1:
                         break
                      Sum_Array.append(a)
                      number_elements += 1
                else:#substracting
                     diff = self.Array[i][3] - Example_Array.Array[j][3] 
                     if diff != 0: 
                        a.append(diff)
                        v = procent * (number_elements+1)#verify if is space for storing the element
                        if v >0.1:
                           break
                        Sum_Array.append(a)
                        number_elements += 1
                i +=1 #we go further in both lists
                j +=1 #

        while(i < n):#if the second list is over and are more in the first elements to add we do that here
             v = procent *(number_elements+1)
             if v >0.1:
                break
             Sum_Array.append(self.Array[i])
             number_elements += 1
             i += 1
        while(j < m): #if the first list is over and are more elements in the second to add we do that here
            #here we do exactly as before. is the second operand so if we substract we have to change signs
             if add==1:
                v = procent *(number_elements+1)
                if v >0.1:
                   break
                Sum_Array.append(Example_Array.Array[j])
                number_elements += 1
             else:
                 Example_Array.Array[j][3] = -Example_Array.Array[j][3]
                 v = procent *(number_elements+1)
                 if v >0.1:
                    break
                 Sum_Array.append(Example_Array.Array[j])
                 number_elements += 1
                 Example_Array.Array[j][3] = -Example_Array.Array[j][3]
             j += 1

        print("The array formed making the operation is:")
        print()
        Sum_Array.Print_Elements()#print the sum_array

    def Menu_Access_Element(self,a,b): #is a menu that appaers when we acces an element
        #when we acces an element we have 3 options
        #print, change with a non-null varible or delete(change with a 0)
        print()
        choice = input("""You accessed the elemen that you wanted. Here some things you can do with the element:
1. Read the element
2. Change the element with a different none-zero value
3. Change the element with a 0 value
Please enter your choice: """)

        if choice == "1":
           print(self.Array[a][b]) #print
           return
        elif choice == "2":
             aux = float(input("Give the value that you want to be changed\n"))
             self.Array[a][b] = aux #change
        elif choice =="3":
              self.Array.pop(a) #delete(change with a 0)
              self.no_elements -= 1

    def Access_Element(self):#we search for an element by it indices and then we call the menu function
         print()
         #read the indices from the keyboard
         print("Give the indices of the specified element. The indices must be bigger than 0 or equal with 0")
         print("Please press enter after every idex")
         lenght_index = int(input())
         width_index = int(input())
         height_index = int(input())
         #the same algorithm as in the print_value function 
         #differs that when we find the element we call the menu function
         b = 0
         for a in range(0,self.no_elements):
             if self.Array[a][b] == lenght_index:
                 b += 1
                 if self.Array[a][b] == width_index:
                    b += 1
                    if self.Array[a][b] == height_index:
                        b += 1
                        self.Menu_Access_Element(a,b) 
                        return
                    else:
                        b = 0
                        continue
                 else:
                     b = 0
                     continue
             else:
                 b = 0
                 continue
         print("This element is not in the list") 

    def Null_Array(self):
        self.Array.clear() #delete all the elements from the array