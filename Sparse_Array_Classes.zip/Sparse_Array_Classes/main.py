import Class_Array

def main(Sparse_Array): ## main function that calls the menu function continnously
   while(1):
       stop_menu = menu(Sparse_Array)
       if(stop_menu == 0): 
           break           

def menu(Sparse_Array):
    choice = input("""
1: Creating the array
2: Printing array
3: Print the dimension of the array 
4: Reading the value of an element specified by its indices
5: Writing the value of an element specified by its indices and by its value
6: Adding and subtracting two arrays
7: Allowing to access an element through its indices
8: Creating a null matrix (with elements having only 0 values)
9: Exit
Please enter your choice: """)

    if choice == "1":
       print()
       op = True ##this varaiable is used for typing errors. if we dont choose from 1 to 4 this op variable will
                 ## signal the error
       choice = input("""                            
1: File test 1: 0 elements can be added
2: File test 2: 2 elements can be added
3: File test 3: 4 elements can be added
4: File test 4: 5 elements can be added
Please enter your choice: """)
       if choice =="1":
           f = open("array1.txt","r") 
       elif choice =="2":
           f = open("array2.txt","r")
       elif choice == "3":
           f = open("array3.txt","r")
       elif choice == "4":
           f = open("array4.txt","r") 
       else:
           op = False
           print("Error") ##signals the error
       if op == True:
          Sparse_Array.Create_Array(f)
          print("The array is created")
       print()
    elif choice == "2":
        print()
        Sparse_Array.Print_Elements() ##prints the elements of the sparse array
    elif choice== "3":
        print()
        Sparse_Array.Print_Dimension() ##prints the dimension of the sparse array
        print()
    elif choice== "4":
        print()
        Sparse_Array.Read_Value() ## we search and print an element by using his indices 
        print()
    elif choice== "5":
        print()
        Sparse_Array.Writing_Value() ## we add (if we can) elements in the sparse array
        print()
    elif choice== "6":
        print()
        print("""For this function to work we need to use the 4-th file from the input 
because we need to have the same dimensions for both Arrays.

If you use another file please use the 8 choice for making the current matrix null
and then use choice 1 and choose the 4-th file""")
        choice =input("""Do you use another file?
0.NO
1.Yes\n
Please enter your choice:\n""")
        if choice == "1":
           Example_Array = Class_Array.Sparse_Array() ## we create another sparase array for adding and subsracting two arrays
           f = open("SumArray.txt","r")
           Example_Array.Create_Array(f)
           Sparse_Array.Add_2_Arrays(Example_Array)
           print()
    elif choice== "7":
        print()
        Sparse_Array.Access_Element() ## we search from an element by its indices and we can either print, change or delete that element 
        print()                    
    elif choice== "8":
        print()
        Sparse_Array.Null_Array() ##we create a null sparse array by deleting all the elements of the list
        print()    
    elif choice== "9":         
        print("Goodbye!")
        return 0         
    else:
        print("Please try again")
 

Sparse_Array = Class_Array.Sparse_Array() ##we use an object type sparse array         
main(Sparse_Array) ##call the main function
